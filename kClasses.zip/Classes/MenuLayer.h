#pragma once
#include"cocos2d.h"
/*�˵���*/
using namespace cocos2d;
class MenuLayer :public CCLayer
{
public:
	MenuLayer();
	CREATE_FUNC(MenuLayer);
	~MenuLayer();
	bool init();
};

